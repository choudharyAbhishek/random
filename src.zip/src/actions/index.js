export const getTemp = (name) => ({
  type: 'GET_TEMP',
  name
});

export const setCityName=(name)=>({
  type:'CITY_NAME',
  name
})

